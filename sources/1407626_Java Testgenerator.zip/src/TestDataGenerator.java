import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

import oracle.jdbc.driver.*;

public class TestDataGenerator {

	/**
	 * Helper Function, reads CSV File and returns it as arrayarray
	 * @param File to read
	 * @returns ArrayList of ArrayList containing Lines and its Fields
	 */
	private static List<List<String>> readFile(String filename) {
		String path = System.getProperty("user.dir")+File.separatorChar+"inputfiles"+File.separatorChar+filename;
		System.out.println(path);
		File c = new File(path);

		List<List<String>> resultify = new ArrayList<List<String>>();
		BufferedReader ingredientsBuffer = null;

		try {
			String ingredientsLine;
			ingredientsBuffer = new BufferedReader(new FileReader(c));
			while ((ingredientsLine = ingredientsBuffer.readLine()) != null) {
				//read each line
				// make arraylist of entrys per line,
				// add this line to arrylist
				List<String> sniffOneLine = new ArrayList<String>();
				if (ingredientsLine != null) {
					String[] splitData = ingredientsLine.split("\\s*;\\s*");
					for (String onePiece : splitData) {
						if (!(onePiece == null))
							if(!(onePiece.length() == 0))
								sniffOneLine.add(onePiece.trim().replace("'", " "));
					}
				}
				resultify.add(sniffOneLine);
			}	
		} catch (IOException e) {
			System.err.println("Error while Reading file: "+c.getAbsolutePath());
			e.printStackTrace();
		} finally {
			try {
				if (ingredientsBuffer != null) ingredientsBuffer.close();
			} catch (IOException ingredientsBufferException) {
				ingredientsBufferException.printStackTrace();
			}
		}
		return resultify;
	}
 
  public static void main(String args[]) {
	  
    try {
    	Class.forName("oracle.jdbc.driver.OracleDriver");
    	String database = "jdbc:oracle:thin:@oracle-lab.cs.univie.ac.at:1521:lab";
    	String user = "a1407626";
    	String pass = "dbs2016";
		
    	// establish connection to database
    	Connection con = DriverManager.getConnection(database, user, pass);
    	Statement stmt = con.createStatement();
    	// insert a single dataset into the database
    	try {
    		//REL_REGUSER
    		try {
    			String filename = "REL_REGUSER_INSERT.csv";
    			List<List<String>> ISA_USER = readFile(filename);
    			
    			for (List<String> list : ISA_USER) {
    				ListIterator<String> el = list.listIterator();
    				//INSERT ISA_USER
    				String insertSql = "INSERT INTO ISA_USER (mailaddress, firstname, lastname) VALUES('"+el.next()+"', '"+el.next()+"','"+el.next()+"')";
    				stmt.executeUpdate(insertSql);
    				
    				//INSERT REL_REGUSER
    				insertSql = "INSERT INTO REL_REGUSER (mailaddress, username, password, moviepoints) VALUES ('"+list.get(0)+"', '"+el.next()+"','"+el.next()+"',"+el.next()+")";
    				stmt.executeUpdate(insertSql);
    			}
			} catch (Exception e) {
				System.out.println("Fehler beim einfügen in ISA_USER \n" + e);
			}
    		//end REL_REGUSER
    		
    		//REL_STAFF
    		try {
    			String filename = "REL_STAFF_INSERT.csv";
    			List<List<String>> ISA_USER = readFile(filename);
    			
    			for (List<String> list : ISA_USER) {
    				ListIterator<String> el = list.listIterator();
    				//INSERT ISA_USER
    				String insertSql = "INSERT INTO ISA_USER (mailaddress, firstname, lastname) VALUES('"+el.next()+"', '"+el.next()+"','"+el.next()+"')";
    				stmt.executeUpdate(insertSql);
    				
    				//INSERT REL_REGUSER
    				insertSql = "INSERT INTO REL_STAFF (mailaddress, staffid, rank, vacationdays) VALUES ('"+list.get(0)+"',"+el.next()+",'"+el.next()+"',"+el.next()+")";
    				stmt.executeUpdate(insertSql);
    			}
			} catch (Exception e) {
				System.out.println("Fehler beim einfügen in REL_STAFF \n" + e);
			}
    		//end REL_STAFF
    		
			ArrayList<String> ISAN = new ArrayList<String>();
    		
    		//TBL_MOVIE
    		try {
    			String filename = "TBL_MOVIE_INSERT.csv";
    			List<List<String>> TBL_MOVIE = readFile(filename);

    			for (List<String> list : TBL_MOVIE) {
    				ListIterator<String> el = list.listIterator();
    
    				//INSERT TBL_MOVIE
    				ISAN.add(list.get(0)); 
					String insertSql = "INSERT INTO TBL_MOVIE (ISAN, TITLE, GENRE) VALUES("+el.next()+", '"+el.next()+"','"+el.next()+"')";

    				try {
        				//System.out.println(insertSql);
        				stmt.executeUpdate(insertSql);
					} catch (Exception e) {
						System.out.print("Error: "); System.out.println(insertSql +e);
						if (!ISAN.isEmpty()) 
							ISAN.remove(ISAN.size()-1);
						continue;
					}
    				
    			}
    			
    				for (int i = 0; i < ISAN.size()-1; i=i+4) {
        				//INSERT TBL_PREQUELS
    					String insertSql = "INSERT INTO tbl_prequels (ISAN1, ISAN2) VALUES("+ISAN.get(i++)+", "+ISAN.get(i)+")";
        				try {
            				stmt.executeUpdate(insertSql);
    					} catch (Exception e) {
    						System.out.print("Error: "); System.out.println(insertSql + e);

    					}
					}
    				
    				//INSERT TBL_ACTOR
    				filename = "TBL_ACTOR_INSERT.csv";
    				List<List<String>> TBL_ACTOR = readFile(filename); 
    				int n=0;
    				for (int i = 0; i < ISAN.size()-1; i++) {
        				//INSERT TBL_ACTOR
    					if (n>450) n=0;
    					
    					String insertSql = "INSERT INTO TBL_ACTOR (ISAN, ACTOR) VALUES("+ISAN.get(i)+", '"+TBL_ACTOR.get(n++)+"')";
        				try {
            				stmt.executeUpdate(insertSql);
    					} catch (Exception e) {
    						System.out.print("Error: "); System.out.println(insertSql + e);

    					}
					}
			} catch (Exception e) {
				System.out.println("Fehler beim einfügen in TBL_MOVIE \n" + e);
			}
    		//end TBL_MOVIE

    		
    		//TBL_CINEMA
    		try {
    			String filename = "TBL_CINEMA_INSERT.csv";
    			List<List<String>> TBL_CINEMA = readFile(filename);
    			for (List<String> list : TBL_CINEMA) {
    				String[] cinemaid = new String[1];
    				cinemaid[0] = "cinemaid";
    				//INSERT TBL_CINEMA 
					String insertSql = "INSERT INTO tbl_cinema(cinemaName,zipcode,city,street,streetnumber,opentimes) VALUES('"+list.get(0)+"', "+list.get(1)+", '"+list.get(2)+"', '"+list.get(3)+"',"+list.get(4)+", '"+list.get(5)+"')";
					PreparedStatement prepstmt = con.prepareStatement(insertSql, cinemaid);
    				try {
        				//System.out.println(insertSql);
        				prepstmt.executeUpdate();
        				ResultSet rs = prepstmt.getGeneratedKeys();
        			
        				int id= -1;
        				if (rs!= null) {
        					rs.next();
            				id = rs.getInt(1);
        				}
 
        				if (id > 0) {
        					
        					for (int i = 1; i < 5; i++) {
        						insertSql = "INSERT INTO tbl_hall(hallId, cinemaId, disaccess, screenarea) VALUES("+i+", "+id+",'"+(0<i%2 ? "y" : "n")+"', "+i*50+")";
        						try {
									stmt.executeUpdate(insertSql);
								} catch (Exception e) {
									System.out.println("Error TBL_HALL" + insertSql + e);
								}
        					}
        				}
        				
					} catch (Exception e) {
						System.out.print("Error CINEMA: "); System.out.println(insertSql +e);
						continue;
					}
    				
    			}
  
    				
			} catch (Exception e) {
				System.out.println("Fehler beim einfügen in TBL_CINEMA \n" + e);
			}
    		//end TBL_CINEMA + HALL
    		
    		//TBL_SHOW
    		try {
    			String filename = "TBL_MOVIE_INSERT.csv";
    			List<List<String>> TBL_CINEMA = readFile(filename);
    			ListIterator<List<String>> el = TBL_CINEMA.listIterator();

    				//INSERT TBL_SHOW
    				/*
    				 * INSERT INTO tbl_show(ISAN, showstart, showend, hallId, cinemaId, agerestriction)
    				 */
    				String insertSql;
    				
    					for (int cinemaid = 1; cinemaid < 4; cinemaid++) {
    						for (int hallid = 1; hallid < 5; hallid++) {
    							for (int day = 10; day < 20; day++) {
    								for (int time = 18; time < 23; time= time+2) {
    									try {
    										if(!el.hasNext()) break;
    										
    										insertSql = "INSERT INTO tbl_show(ISAN, showstart, showend, hallId, cinemaId, agerestriction) "
    												+ "VALUES ("+el.next().get(0)+", TO_DATE('"+day+".02.2016 "+time+":00', 'DD.MM.YYYY HH24:MI'), TO_DATE('"+day+".02.2016 "+(time+1)+":59', 'DD.MM.YYYY HH24:MI'),"+hallid+", "+cinemaid+", 16)";
    										stmt.executeUpdate(insertSql);
    									} catch (Exception e) {
    										System.out.print("Fehler beim einfügen in TBL_SHOW \n" + e); 
    										continue;
    								}	
								}
    						}
    					}
    				}
			} catch (Exception e) {
				System.out.println("Fehler beim einfügen in TBL_SHOW \n" + e);
			}
    		


      		//REL_RESERVATION
      		try {
      			String ps;
      			ResultSet rs;
        	    Random rand = new Random();
      			
      			//get all shows
      			ps = "Select tbl_show.showid from tbl_show";
      			rs = stmt.executeQuery(ps);
      			ArrayList<Integer> shows =  new ArrayList<>();
      			while (rs.next()) {
      			    shows.add(rs.getInt(1));  //get value form column 1
      			}
      			
      			ps = "Select rel_reguser.mailaddress from rel_reguser";
      			rs = stmt.executeQuery(ps);
      			// get all reg_users
      			ArrayList<String> reguser =  new ArrayList<>();
      			
      			while (rs.next()) {
      			    reguser.add(rs.getString(1));  //get value form column 1
      			}
      			
      			String insertSql;
      			for (int i = 0; i <20000; i++) {
      				insertSql = "INSERT INTO rel_reservation(mailaddress, showId, rowNr, seatNr) VALUES ('"+reguser.get(rand.nextInt(reguser.size()))+"', "+shows.get(rand.nextInt(shows.size()))+", "+(rand.nextInt(10)+1)+", "+(rand.nextInt(15)+1)+")";
      				try {
      					stmt.executeUpdate(insertSql);
					} catch (Exception e) {
						System.out.println(insertSql);
						continue;
					}
      				
      			}
  			} catch (Exception e) {
  				System.out.println("Fehler beim einfügen in TBL_RESERVATION \n" + e);
  			}
    		
  

    	} catch (Exception e) {
    		System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
    	}
    	//END REL_RESERVATION
    	
    	// check number of datasets in person table
    	ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM TBL_MOVIE");
    	if (rs.next()) {
    	  int count = rs.getInt(1);
    	  System.out.println("Elements in movie: " + count);
    	}
    	// check number of datasets in person table
    	 rs = stmt.executeQuery("SELECT COUNT(*) FROM REL_RESERVATION");
    	if (rs.next()) {
    	  int count = rs.getInt(1);
    	  System.out.println("Elements in reservation: " + count);
    	}
	    	// check number of datasets in person table
	   	 rs = stmt.executeQuery("SELECT COUNT(*) FROM ISA_USER");
	   	if (rs.next()) {
	   	  int count = rs.getInt(1);
	   	  System.out.println("Elements in users: " + count);
	   	}
		 // check number of datasets in person table
	   	 rs = stmt.executeQuery("SELECT COUNT(*) FROM TBL_SHOW");
	   	if (rs.next()) {
	   	  int count = rs.getInt(1);
	   	  System.out.println("Elements in show: " + count);
	   	}
    	
    	// clean up connections
    	rs.close();
    	stmt.close();
    	con.close();
    	
    	
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }
}  